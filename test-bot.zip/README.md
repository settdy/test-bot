# Discord Bot

## 1 How to install this
1. Download this file as a zip file
2. Remove (example) from .envexample
3. Configure the .env file with your own settings
4. run the following commands:
   ```console
   npm init -y
   npm install discord.js dotenv fs path
   node index.js 
   ```